function tellFortune(job, location, partner, kids) {
    var future = 'You will be a ' + job + ' in ' + location + ' and married to ' +
    partner + ' ' + ' with ' + kids + ' kids.';
    console.log(future);
}

tellFortune('nba player', 'LA', 'Sommer Ray', 3);
tellFortune('Actor', 'Chicago', 'Scarlet Johanson', 4);
tellFortune('Bank teller', 'New york', 'Trump', 2);
